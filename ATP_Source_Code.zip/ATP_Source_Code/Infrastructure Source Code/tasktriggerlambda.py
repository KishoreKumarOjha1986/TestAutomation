import boto3
import json
s3_client = boto3.client('s3')
ecs_client = boto3.client('ecs')

def lambda_handler(event, context):
    bucket = event['Records'][0]['s3']['bucket']['name'] #Get the event from s3
    s3_json_filename = event['Records'][0]['s3']['object']['key']
    print(f"The request is from the bucket:{bucket}")
    print(f"The input file path is: {s3_json_filename}")
    print ("object event get completed... ")
    s3_object_input_path = f"s3://{bucket}/{s3_json_filename}"
    s3_report_path = s3_object_input_path.split("/input/input.json")[0] + "/report"
    s3_result_path = s3_object_input_path.split("/input/input.json")[0] + "/result"
    print(f"The aboslute path is: {s3_object_input_path}")
    print(f"The report path is: {s3_report_path}")
    print(f"The report path is: {s3_result_path}")
    json_input = s3_client.get_object(Bucket=bucket,Key=s3_json_filename)
    jsonInputFileReader = json_input['Body'].read()
    jsonInputDict = json.loads(jsonInputFileReader) ##To load the json as dictionary
    task = jsonInputDict['taskname'] #Getting the task name from the user supplied input.json
    print(f"The test case to be executed is: {task}")
    task_to_execute = f"{task}-app"
    response_from_ecs_taskdefinition = ecs_client.list_task_definitions(
        status='ACTIVE',
        sort='ASC',
        maxResults=50)
    taskARNslist = response_from_ecs_taskdefinition['taskDefinitionArns']
    for taskARNs in taskARNslist:
        if task in taskARNs:            
            task_to_run = taskARNs.split("/")[1]
    print(f"The taskdefinition to be called is: {task_to_run}")
    response_to_ecs_task = ecs_client.run_task(
    cluster='ATSECSCluster-Dev',
    taskDefinition= f'{task_to_run}',
    networkConfiguration={
        'awsvpcConfiguration': {
            'subnets': [
                'subnet-0ee027956f93d6170',
            ],
            'assignPublicIp': 'ENABLED'
        }
    },
    overrides={
        'containerOverrides': [
            {                             
                'name': f"{task_to_execute}",
                'environment': [
                    {
                        'name': 'inputfilepath',
                        'value': f'{s3_object_input_path}'
                    },
                    {
                        'name': 'reportpath',
                        'value': f'{s3_report_path}'
                    },
                    {
                        'name': 'resultpath',
                        'value': f'{s3_result_path}'
                    },
                ], 
            },
        ],        
    },    
    launchType='FARGATE'   
)
    print(f"The task: {task_to_execute} execution started")
    return "Hello from Lambda"