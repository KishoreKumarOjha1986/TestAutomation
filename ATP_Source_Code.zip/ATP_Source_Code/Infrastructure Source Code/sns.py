import boto3
import os

SNS_client = boto3.client('sns', region_name='us-east-1')

with open("/root/input.json", 'r') as file:
    input = json.load(file)

vitialize_id = input['vitialize_id']
taskname = input['taskname']

report_path = os.environ['report_path']
result_path = os.environ['result_path']

topicArn = ""
SNS_message = """Report File Path : {}
                 Result File Path : {}""".format(report_path, result_path)

SNS_subject = "{}-{}".format(vitialize_id, taskname)
SNS_client.publish(TopicArn=topicArn, Subject=SNS_subject, Message=SNS_message)