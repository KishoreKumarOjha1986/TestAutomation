import boto3
import json

with open("/root/input.json") as file:
    data = json.load(file)
with open("/root/secret.json") as file:
    secret = json.load(file)

source_bucket_name = data['source_bucket_name']
target_bucket_name = data['target_bucket_name']
source_key = data['source_key']
target_key = data['target_key']

access_id = secret['AccessKeyId']
secret_key = secret['SecretAccessKey']
token = secret['Token']

s3 = boto3.client("s3",
aws_access_key_id=access_id,
aws_secret_access_key=secret_key,
aws_session_token=token)

s3.download_file(source_bucket_name,source_key,'/root/source.csv')
s3.download_file(target_bucket_name,target_key,'/root/target.csv')
