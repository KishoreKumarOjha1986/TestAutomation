#!/bin/bash
echo $inputfilepath
echo $reportpath
echo $resultpath
curl 169.254.170.2$AWS_CONTAINER_CREDENTIALS_RELATIVE_URI >> /root/secret.json
cat /root/secret.json
aws s3 cp $inputfilepath /root/input.json
python3.6 /getfile.py
cd /root/validaterowcolumncount/
behave | tee /root/result.txt
behave -f allure_behave.formatter:AllureFormatter -o allure/results ./ValidateRowColmn.feature
/root/allure-2.10.0/bin/allure generate allure/results/ -o /root/allure/reports
aws s3 cp /root/result.txt $resultpath/result.txt
cd /root/allure/reports
pwd
zip -r /root/reports.zip *
aws s3 cp /root/reports.zip $reportpath/reports.zip 
